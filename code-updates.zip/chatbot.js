(() => {
  "use strict";
  if (document.getElementById("rp-chat-host")) return;
  const endpoint = "https://akfnlsyvjlxkdibfhuzy.supabase.co/functions/v1/raman-chat";
  const publicKey = "sb_publishable_TbNJKpXMKCv6bcjSDgpUwA_FLS1SsFz";
  const anonJwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFrZm5sc3l2amx4a2RpYmZodXp5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTI2NzEzMDMsImV4cCI6MjEwODI0NzMwM30.FcL_imdBoozzL2W5_iJ47ZwqcuJerGpCzvyjItgp5qc";
  
  const host = document.createElement("div"); host.id = "rp-chat-host";
  const shadow = host.attachShadow({mode:"open"});
  shadow.innerHTML = `
    <style>
      :host{all:initial;font-family:Georgia,system-ui,-apple-system,"Segoe UI",sans-serif;color:#27251f}*{box-sizing:border-box}
      .launcher{position:fixed;z-index:2147483000;right:20px;bottom:20px;border:1px solid rgba(185,145,75,0.4);border-radius:999px;background:linear-gradient(135deg,#642c2a,#47201f);color:#fff;padding:13px 20px;font-size:15px;font-weight:700;box-shadow:0 8px 24px rgba(74,43,24,0.3);cursor:pointer;display:inline-flex;align-items:center;gap:8px;transition:all .2s ease}
      .launcher:hover{transform:translateY(-2px);box-shadow:0 12px 28px rgba(74,43,24,0.4);background:#713b23}
      .panel{position:fixed;z-index:2147483001;right:18px;bottom:82px;width:min(420px,calc(100vw - 24px));height:min(660px,calc(100dvh - 108px));background:#fffdf8;border:1px solid #ddcfb8;border-radius:20px;box-shadow:0 16px 50px rgba(74,43,24,0.22);display:none;grid-template-rows:auto auto auto 1fr auto auto;overflow:hidden}.panel[open]{display:grid}
      .head{display:flex;align-items:center;justify-content:space-between;padding:14px 18px;background:linear-gradient(135deg,#fbf4e6,#f4e6ce);border-bottom:1px solid #e2d3be}.brand{font-size:17px;font-weight:800;color:#542e1d;display:flex;align-items:center;gap:6px}.sub{font-size:11px;color:#705d47;margin-top:2px;font-style:italic}.tag{font-size:10px;color:#85542f;margin-top:3px;font-weight:600;letter-spacing:0.04em}.head button,.voice-controls button{border:0;background:transparent;font-size:22px;cursor:pointer;color:#51412e}
      .privacy{padding:7px 14px;background:#fff8ea;color:#6b573b;font-size:11px;line-height:1.45;border-bottom:1px solid #ede1cf}.suggestions{display:flex;gap:6px;padding:8px 12px;overflow-x:auto;border-bottom:1px solid #eee4d5;background:#fffaf3}.suggestions button{flex:0 0 auto;border:1px solid #dbcaa8;border-radius:999px;background:#fffdf9;color:#633b24;padding:5px 11px;font-size:11px;cursor:pointer;transition:background .15s}.suggestions button:hover{background:#f3e3ca}
      .messages{overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:12px;scroll-behavior:smooth}.msg{border-radius:15px;padding:12px 14px;font-size:13.5px;line-height:1.6;max-width:96%;overflow-wrap:anywhere;white-space:pre-wrap}.user{align-self:flex-end;background:#eedfcb;color:#39261a;border-bottom-right-radius:4px}.bot{align-self:flex-start;background:#f7f4ee;color:#29221b;width:100%;border:1px solid #e8decb;border-bottom-left-radius:4px}
      .msg h4{font-size:13px;margin:8px 0 4px;color:#633c22;font-weight:700}.msg h4:first-child{margin-top:0}.passage{padding:10px 0;border-top:1px dashed #d5c8b5}.verse{font-family:Georgia,serif;font-size:16px;line-height:1.8;color:#47201f;margin:8px 0;background:#fffaf1;padding:10px;border-radius:8px;border-left:3px solid #b9914b;white-space:pre-wrap}.small{font-size:12.5px;color:#5a4f43;margin-top:5px}.sources a{color:#7c431d;text-decoration:underline;font-weight:600}.notice{font-size:11px;color:#735b3e;padding-top:6px}
      .composer{display:flex;gap:7px;padding:10px;border-top:1px solid #e5d7c3;background:#fffdf9;align-items:center}.composer textarea{flex:1;min-width:0;resize:none;height:46px;border:1px solid #ccbfa7;border-radius:10px;padding:9px 11px;font:13.5px system-ui,sans-serif;background:#fff}.composer button{border:0;border-radius:10px;background:#642c2a;color:white;padding:0 14px;height:42px;font-weight:700;cursor:pointer;transition:background .2s}.composer button:hover{background:#47201f}.composer button[disabled]{opacity:.55}.mic{width:42px;padding:0!important;font-size:18px!important}.tools{display:flex;justify-content:space-between;align-items:center;padding:0 14px 8px;font-size:11px;color:#625b51;background:#fffdf9}.tools select{padding:4px 6px;border:1px solid #cebfa8;border-radius:7px;background:#fffdf8}.voice-controls{display:flex;gap:5px;align-items:center}.voice-controls button{font-size:14px;border:1px solid #dfd1bd;border-radius:6px;padding:3px 7px;background:#fffdf8}.typing{color:#6c5e4a;font-size:12px;font-style:italic}.error{color:#98231c;background:#fdeeee;border:1px solid #f3cfce}.sr{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
      @media(max-width:480px){.panel{right:6px;left:6px;bottom:72px;width:auto;height:min(620px,calc(100dvh - 84px));border-radius:16px}.messages{padding:10px}}
    </style>
    <button class="launcher" aria-haspopup="dialog" aria-expanded="false" aria-label="Open Tabhai Prabhu chat">🦚 Ask Tabhai Prabhu</button>
    <section class="panel" role="dialog" aria-label="Tabhai Prabhu spiritual chat" aria-modal="false">
      <header class="head"><div><div class="brand">Tabhai Prabhu 🦚</div><div class="sub">Shan Prabhu ka chhota bhai 😂</div><div class="tag">Shastra • Bhakti • Seva • Thodi si Masti</div></div><button class="close" aria-label="Close chat">×</button></header>
      <div class="privacy">Bhai, koi bhi shloka number pucho (jaise <strong>BG 2.47</strong> ya <strong>4.7</strong>) ya dil ki baat share karo! Main shastra aur prem dono se samjhaunga. 🙏</div>
      <div class="suggestions" aria-label="Suggested questions">
        <button data-q="Gita 2.47">Gita 2.47</button>
        <button data-q="Gita 4.7">Gita 4.7</button>
        <button data-q="Gita 18.66">Gita 18.66</button>
        <button data-q="Prabhu chanting me mann nahi lag raha">Mann nahi lag raha</button>
        <button data-q="Govardhan yatra kab hai?">Govardhan Yatra</button>
      </div>
      <div class="messages" aria-live="polite">
        <div class="msg bot">Areyyy 😂 Radhe Radhe bhai! Main hoon Tabhai Prabhu (Shan Prabhu ka chhota bhai). Kya haal-chaal? Bhagavad Gita ka koi bhi shloka pucho ya sadhana pe charcha karein! 🦚</div>
      </div>
      <div class="tools"><label>Language <select aria-label="Answer language"><option value="auto">Auto</option><option value="hi">हिन्दी / Hinglish</option><option value="en">English</option></select></label><div class="voice-controls"><button class="read" aria-label="Toggle read aloud" title="Read answers aloud">🔊</button><button class="pause" aria-label="Pause or resume speech" title="Pause / resume">Ⅱ</button><button class="stop" aria-label="Stop speech" title="Stop speaking">■</button><span class="state">Ready</span></div></div>
      <form class="composer"><textarea maxlength="1000" required aria-label="Your question" placeholder="Ask Tabhai… koi bhi shloka ya sawal pucho"></textarea><button class="mic" type="button" aria-label="Speak your question" title="Tap to speak">🎙</button><button class="send" type="submit">Send</button></form>
      <span class="sr" aria-live="polite" id="voice-status"></span>
    </section>`;
    
  document.body.appendChild(host);
  const $=s=>shadow.querySelector(s),launcher=$(".launcher"),panel=$(".panel"),messages=$(".messages"),form=$("form"),textarea=$("textarea"),state=$(".state"),voiceStatus=$("#voice-status");
  launcher.addEventListener("click",()=>{panel.toggleAttribute("open");launcher.setAttribute("aria-expanded",String(panel.hasAttribute("open")));if(panel.hasAttribute("open"))textarea.focus();});
  $(".close").addEventListener("click",()=>{panel.removeAttribute("open");launcher.setAttribute("aria-expanded","false");stopListening();window.speechSynthesis?.cancel();launcher.focus();});
  shadow.addEventListener("keydown",e=>{if(e.key==="Escape"&&panel.hasAttribute("open"))$(".close").click();});

  function node(tag,cls,text,parent){const el=document.createElement(tag);if(cls)el.className=cls;if(text!==undefined)el.textContent=text;parent.appendChild(el);return el;}
  function linkLine(parent,title,url){if(!url)return;const a=document.createElement("a");a.href=url;a.target="_blank";a.rel="noopener noreferrer";a.textContent=title;a.className="source-link";parent.appendChild(a);}
  let latestAnswer="";

  // High-precision Shloka Lookup from Keyless 700-verse Bhagavad Gita API
  async function fetchGitaSlok(ch, sl) {
    try {
      const res = await fetch(`https://vedicscriptures.github.io/slok/${ch}/${sl}`);
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  }

  function parseGitaVerse(q) {
    const clean = q.toLowerCase().replace(/[-_:,]/g, " ").replace(/\s+/g, " ").trim();
    const m = clean.match(/(?:bhagavad\s*gita|gita|bg|adhyay|chapter)?\s*(\d{1,2})\s*(?:verse|slok|shlok|adhyaya)?\s*[\.\s\:\/]\s*(\d{1,2})/i);
    if (m) {
      const ch = parseInt(m[1], 10), sl = parseInt(m[2], 10);
      if (ch >= 1 && ch <= 18 && sl >= 1 && sl <= 78) return { ch, sl };
    }
    return null;
  }

  // Pre-compiled Gaudiya & Shastric Treasury
  const GAUDIYA_TREASURY = {
    "sb 1.2.6": {
      ref: "Śrīmad-Bhāgavatam 1.2.6",
      sanskrit: "स वै पुंसां परो धर्मो यतो भक्तिरधोक्षजे ।\nअहैतुक्यप्रतिहता ययात्मा सुप्रसीदति ॥",
      translit: "sa vai puṁsāṁ paro dharmo yato bhaktir adhokṣaje\nahaituky apratihatā yayātmā suprasīdati",
      hi: "मनुष्य का सर्वोच्च धर्म वही है जिससे भगवान अधोक्षज (इन्द्रियों से परे) के प्रति निष्काम और निरंतर प्रेममयी भक्ति उत्पन्न हो। ऐसी भक्ति से ही आत्मा को पूर्ण शांति और संतोष मिलता है।",
      tip: "Bhai, jab bhi lage ki jeevan mein kuch kami hai ya mann bechain hai, yaad rakhna—sirf bhagwat-bhakti hi aatma ko sacha sukoon de sakti hai!",
      url: "https://vedabase.io/en/library/sb/1/2/6/"
    },
    "bs 5.1": {
      ref: "Śrī Brahma-saṁhitā 5.1",
      sanskrit: "ईश्वरः परमः कृष्णः सच्चिदानन्दविग्रहः ।\nअनादिरादिर्गोविन्दः सर्वकारणकारणम् ॥",
      translit: "īśvaraḥ paramaḥ kṛṣṇaḥ sac-cid-ānanda-vigrahaḥ\nanādir ādir govindaḥ sarva-kāraṇa-kāraṇam",
      hi: "श्रीकृष्ण ही परम ईश्वर हैं, जिनका स्वरूप सत्, चित् और आनन्दमय है। वे अनादि हैं, सबके आदि हैं और समस्त कारणों के मूल कारण हैं।",
      tip: "Govinda hi sabke source hain. Bas unke charano ki sharan mein raho, sab theek hoga!",
      url: "https://vedabase.io/en/library/bs/5/1/"
    },
    "cc 20.108": {
      ref: "Śrī Caitanya-caritāmṛta, Madhya 20.108",
      sanskrit: "जीवरे ‘स्वरूप’ हय—कृष्णेर ‘नित्य-दास’ ।\nकृष्णेर ‘तटस्था-शक्ति’ ‘भेदाभेद-प्रकाश’ ॥",
      translit: "jīvera ‘svarūpa’ haya—kṛṣṇera ‘nitya-dāsa’\nkṛṣṇera ‘taṭasthā-śakti’ ‘bhedābheda-prakāśa’",
      hi: "जीव का वास्तविक सनातन स्वरूप श्रीकृष्ण का नित्य दास होना है। जीव कृष्ण की तटस्था शक्ति है।",
      tip: "Hum kisi ke ghulam nahi, par Krishna ke nitya sevak hain—aur yahi humari sachhi azadi aur anand hai!",
      url: "https://vedabase.io/en/library/cc/madhya/20/108-109/"
    }
  };

  // Empathetic Devotee Friend Responses
  function handleSpiritualEmpathy(q) {
    const text = q.toLowerCase();
    if (text.includes("mann nahi lag") || text.includes("man nahi lag") || text.includes("focus nahi") || text.includes("wandering")) {
      return {
        answer: "Arey bhai ❤️ bilkul tension mat lo! Har bhakt ke jeevan mein aisa time aata hai jab mann bhatakta hai ya thakaan hoti hai.\n\n" +
          "Arjuna ne bhi Shri Krishna se yehi kaha tha: 'Chanchalam hi manah Krishna...' (Gita 6.34) ki mann ko rokna hawa ko rokne jaisa mushkil hai!\n\n" +
          "Toh Krishna ne kya solution diya? (Gita 6.35):\n" +
          "«अभ्यासेन तु कौन्तेय वैराग्येण च गृह्यते»\n" +
          "Yaani ghabraane ki zaroorat nahi hai—sirf abhyas (practice) se mann sadh jaata hai!\n\n" +
          "🎯 Mera chhota sa devotional tip:\n" +
          "1. 16 round ka bojh mat socho, bas agle 1 round ko dhyan se 'Hare Krishna' sunte hue jap lo.\n" +
          "2. 5 minute Shri Radharaman Ji ka kirtan ya darshan kar lo.\n" +
          "Mann bhatke toh pyaar se bolo: 'Arey mann, chal Krishna ke paas chalte hain!' Samajh gaye bhai? 😄"
      };
    }
    if (text.includes("yatra") || text.includes("govardhan")) {
      return {
        answer: "Radhe Radhe! 🪷 Raman Parikar ki agami **Govardhan Dham Yatra** 20 se 22 November 2026 ko ho rahi hai!\n\n" +
          "• Registration fee: ₹1,500 per participant\n" +
          "• Online payment: UPI QR Goldy Tiwari (7209078204@ptyes)\n" +
          "• Form bharne ke liye hamari website ke Yatra page par jaao, aur register kar lo! WhatsApp helpline: +91 83683 19854"
      };
    }
    if (text.includes("who is krishna") || text.includes("krishna kaun")) {
      return {
        answer: "Arey bhai, Brahma Samhita 5.1 mein Brahma Ji swayam kehte hain:\n\n" +
          "«ईश्वरः परमः कृष्णः सच्चिदानन्दविग्रहः । अनादिरादिर्गोविन्दः सर्वकारणकारणम् ॥»\n\n" +
          "Krishna koi sadharan vyakti nahi, balki param ishwar, prem aur anand ke sagar hain! Aur humare Shri Radharaman Ji unhi ke sabse madhur aur kripalu swaroop hain. 🦚✨"
      };
    }
    return null;
  }

  function renderData(data) {
    const box = node("div", "msg bot", undefined, messages);
    if (data.kind === "shloka") {
      node("h4", "", `📜 ${data.title}`, box);
      node("div", "verse", data.sanskrit, box);
      if (data.translit) node("div", "small", `🔤 Transliteration: ${data.translit}`, box);
      if (data.meaning_hi) node("div", "small", `💡 भावार्थ: ${data.meaning_hi}`, box);
      if (data.meaning_en) node("div", "small", `📖 Meaning: ${data.meaning_en}`, box);
      if (data.tip) {
        node("h4", "", "🦚 Tabhai Prabhu ka Devotional Tip:", box);
        node("div", "", data.tip, box);
      }
      if (data.url) {
        node("div", "notice", "", box);
        linkLine(box, "👉 View Authentic Shloka at Vedabase / Shastra", data.url);
      }
    } else {
      node("div", "", data.answer, box);
    }
    latestAnswer = data.answer || data.meaning_hi || data.sanskrit || "";
    if (speakEnabled) speak(latestAnswer);
    messages.scrollTop = messages.scrollHeight;
  }

  // Voice speech synthesis
  function detectLanguage(text){return /[\u0900-\u097F]/.test(text)?"hi":"en";}
  function speak(text){if(!text||!window.speechSynthesis)return;window.speechSynthesis.cancel();const utterance=new SpeechSynthesisUtterance(text);const lang=$("select").value==="auto"?detectLanguage(textarea.value||text):$("select").value;utterance.lang=lang==="hi"?"hi-IN":"en-IN";const voices=speechSynthesis.getVoices();const voice=voices.find(v=>v.lang.toLowerCase().startsWith(lang==="hi"?"hi":"en-in"))||voices.find(v=>v.lang.toLowerCase().startsWith(lang));if(voice)utterance.voice=voice;speechSynthesis.speak(utterance);}
  let speakEnabled=false,recognition=null,listening=false;
  function stopListening(){if(recognition&&listening){try{recognition.stop();}catch{} }listening=false;$(".mic").setAttribute("aria-pressed","false");}
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  $(".mic").addEventListener("click",()=>{if(!SR){voiceStatus.textContent="Speech recognition not supported in this browser.";state.textContent="Voice unavailable";return;}if(listening){stopListening();return;}recognition=new SR();recognition.interimResults=true;recognition.continuous=false;const chosen=$("select").value;recognition.lang=chosen==="hi"?"hi-IN":"en-IN";recognition.onstart=()=>{listening=true;$(".mic").setAttribute("aria-pressed","true");state.textContent="Listening…";voiceStatus.textContent="Listening...";};recognition.onresult=e=>{let final="",interim="";for(let i=e.resultIndex;i<e.results.length;i++){if(e.results[i].isFinal)final+=e.results[i][0].transcript;else interim+=e.results[i][0].transcript;}textarea.value=(final||interim).trim();if(final){state.textContent="Ready to send";textarea.focus();}};recognition.onerror=()=>{listening=false;$(".mic").setAttribute("aria-pressed","false");state.textContent="Ready";};recognition.onend=()=>{listening=false;$(".mic").setAttribute("aria-pressed","false");if(state.textContent==="Listening…")state.textContent="Ready";};try{recognition.start();}catch{state.textContent="Ready";}});
  $(".read").addEventListener("click",()=>{speakEnabled=!speakEnabled;if(speakEnabled&&latestAnswer)speak(latestAnswer);else if(!speakEnabled)window.speechSynthesis?.cancel();state.textContent=speakEnabled?"Read aloud on":"Read aloud off";});
  $(".pause").addEventListener("click",()=>{if(!window.speechSynthesis)return;if(speechSynthesis.speaking&&!speechSynthesis.paused){speechSynthesis.pause();state.textContent="Speech paused";}else if(speechSynthesis.paused){speechSynthesis.resume();state.textContent="Speaking…";}else state.textContent="Nothing playing";});
  $(".stop").addEventListener("click",()=>{window.speechSynthesis?.cancel();speakEnabled=false;state.textContent="Read aloud off";});
  shadow.querySelectorAll(".suggestions button").forEach(button=>button.addEventListener("click",()=>{textarea.value=button.dataset.q;form.requestSubmit();}));

  // Submission handler
  form.addEventListener("submit", async e => {
    e.preventDefault();
    const query = textarea.value.trim();
    if (!query) return;
    node("div", "msg user", query, messages);
    textarea.value = "";
    state.textContent = "Thinking…";
    $(".send").disabled = true;
    const typing = node("div", "msg bot typing", "Tabhai Prabhu is contemplating… 🦚", messages);
    messages.scrollTop = messages.scrollHeight;

    try {
      // 1. Check for ANY Bhagavad Gita Verse Request (e.g. "BG 4.7", "Gita 2.47", "18.66")
      const gitaRef = parseGitaVerse(query);
      if (gitaRef) {
        const slokData = await fetchGitaSlok(gitaRef.ch, gitaRef.sl);
        if (slokData && slokData.slok) {
          typing.remove();
          const hiMeaning = slokData.tej?.ht || slokData.rams?.ht || "";
          const enMeaning = slokData.prabhu?.et || slokData.siva?.et || "";
          renderData({
            kind: "shloka",
            title: `Bhagavad Gītā Chapter ${gitaRef.ch}, Verse ${gitaRef.sl}`,
            sanskrit: slokData.slok,
            translit: slokData.transliteration || "",
            meaning_hi: hiMeaning,
            meaning_en: enMeaning,
            tip: `Bhai! Shri Krishna ne Adhyay ${gitaRef.ch} ke shloka ${gitaRef.sl} mein yeh divya gyan diya hai. Isko daily life mein utaro aur Radharaman Ji ka smaran karo! 🙏`,
            url: `https://vedabase.io/en/library/bg/${gitaRef.ch}/${gitaRef.sl}/`
          });
          state.textContent = "Ready";
          return;
        }
      }

      // 2. Check for Gaudiya Treasury Verses (SB, CC, BS)
      const lower = query.toLowerCase();
      for (const [key, item] of Object.entries(GAUDIYA_TREASURY)) {
        if (lower.includes(key)) {
          typing.remove();
          renderData({
            kind: "shloka",
            title: item.ref,
            sanskrit: item.sanskrit,
            translit: item.translit,
            meaning_hi: item.hi,
            tip: item.tip,
            url: item.url
          });
          state.textContent = "Ready";
          return;
        }
      }

      // 3. Empathetic Spiritual Buddy Check
      const empathy = handleSpiritualEmpathy(query);
      if (empathy) {
        typing.remove();
        renderData(empathy);
        state.textContent = "Ready";
        return;
      }

      // 4. Fallback to Supabase Endpoint
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json", apikey: publicKey, Authorization: `Bearer ${anonJwt}` },
        body: JSON.stringify({ message: query, language: $("select").value })
      });
      const data = await response.json();
      typing.remove();
      if (data.answer || data.interpretation) {
        renderData({ answer: data.answer || data.interpretation });
      } else {
        renderData({ answer: "Radhe Radhe bhai! 🙏 Kuch aur shastra charcha ya koi shloka number (jaise BG 2.47 ya BG 4.7) poochna ho toh batao!" });
      }
      state.textContent = "Ready";
    } catch {
      typing.remove();
      renderData({
        answer: "Radhe Radhe bhai! 🙏 Main Tabhai Prabhu. Aap koi bhi shloka number (jaise Gita 2.47, BG 4.7, 18.66) pucho ya mann ki baat batao, main shastra aur prem se reply karunga!"
      });
      state.textContent = "Ready";
    } finally {
      $(".send").disabled = false;
    }
  });
})();
